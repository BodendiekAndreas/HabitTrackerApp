from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, abort
from flask_login import login_user, logout_user, current_user
from werkzeug.security import check_password_hash, generate_password_hash

from .. import db
from ..models import User
from ..forms import LoginForm, RegistrationForm
from ..extensions import login_manager

# Define the blueprint
auth_bp = Blueprint('auth', __name__, url_prefix='/auth')


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


def is_safe_url(target):
    if target:
        # Check if the redirect is to a URL within the same site
        if target.startswith('/'):
            return True
    return False


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        current_app.logger.info("User already authenticated, redirecting to main index.")
        return redirect(url_for('main.index'))

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            current_app.logger.debug("Checking password for user: " + user.email)
            if check_password_hash(user.password_hash, form.password.data):
                login_user(user, remember=form.remember.data)  # Remember flag added here
                current_app.logger.info("Login successful, redirecting.")
                next_page = request.args.get('next')
                if next_page and not is_safe_url(next_page):
                    return abort(400)
                return redirect(next_page or url_for('main.index'))
            else:
                flash('Login Unsuccessful. Please check email and password', 'error')
                current_app.logger.warning("Password check failed for user: " + user.email)
        else:
            flash('No user found with that email.', 'error')
            current_app.logger.warning("No user found with the email: " + form.email.data)

    return render_template('login.html', title='Login', form=form)


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = generate_password_hash(form.password.data)
        user = User(username=form.username.data, email=form.email.data, password_hash=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You are now able to log in', 'success')
        return redirect(url_for('auth.login'))
    return render_template('register.html', title='Register', form=form)


@auth_bp.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('main.index'))
